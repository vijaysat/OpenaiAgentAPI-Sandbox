# coding: utf-8
# Copyright (c) 2016, 2026, Oracle and/or its affiliates.  All rights reserved.
# This software is dual-licensed to you under the Universal Permissive License (UPL) 1.0 as shown at https://oss.oracle.com/licenses/upl or Apache License 2.0 as shown at http://www.apache.org/licenses/LICENSE-2.0. You may choose either license.

from pydantic import BaseModel, Field

from oci.addons.adk.run.types import InlineInputLocation, ObjectStorageInputLocation


class ApiEndpointTool(BaseModel):
    """Represents a custom api endpoint tool with configuration pointing to virtual compute network for server side tool-based execution."""
    name: str = Field(description="The name of the tool, used for identification and invocation")
    description: str = Field(description="Human-readable description of what the tool does and how to use it")
    api_schema: InlineInputLocation | ObjectStorageInputLocation = Field(description="The OpenApi schema of the endpoint")
    authentication_type: str = Field(description="The authorization scope to use for authentication")
    subnet_id: str = Field(description="The subnet id of the virtual compute network where api execution will be routed")
    key_location: str = Field(default=None, description="Token location for authentication")
    key_name: str = Field(default=None, description="Authentication key name")
    secret_ocid: str = Field(default=None, description="Ocid of the secret containing authorization token")
    model_config = {'arbitrary_types_allowed': True}

    # Equality comparison
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ApiEndpointTool):
            return NotImplemented
        return (
            self.name == other.name and
            self.description == other.description and
            self.api_schema == other.api_schema and
            self.secret_ocid == other.secret_ocid
        )
